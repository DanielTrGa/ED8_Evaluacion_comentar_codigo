/**
 * La clase "EntradaBlog_INICIALES" se usa para introducir los datos de los autores.
 * La modificaci�n de la clase ha sido el cambio de nombre, sustituyendo el simbolo "+", por "_" ya que el simbolo "+" no lo aceptaba.
 * 
 * @version 2.3
 * @author Daniel
 * @since 25-02-2022
 */

public class EntradaBlog_INICIALES {
	
	/**
	 * Atributo separador de la EntradaBlog_INICIALES.
	 * Separador es el car�cter que separa ENTRADA DE del autor (nombre del autor).
	 */
	
	public static char separador=':';
	
	/**
	 * Atributo id de la EntradaBlog_INICIALES.
	 * Es el id que se le da a la entrada introducida.
	 */
	
	private int id;
	
	/**
	 * Atributo texto de la EntradaBlog_INICIALES.
	 * Es el texto completo de la introducida.
	 */
	
	private String texto;
	
	/**
	 * Atributo autor de la EntradaBlog_INICIALES.
	 * Es el autor de la entrada introducida.
	 */
	
	private String autor;
	
	/**
	 * Constructor con 3 parametros.
	 * Crea objetos EntradaBlog_INICIALES, con id, autor y texto.
	 * @param id <i> id de la entrada introducida. </i>
	 * @param autor <i> nombre del autor de la entrada introducida. </i>
	 * @param texto <i> texto de la entrada introducida. </i>
	 * @throws IllegalArgumentException <i> Arroja la excepci�n "IllegalArgumentException" cuando el ig introducido es 0 o inferior. </i>
	 */
	
	public EntradaBlog_INICIALES(int id,String autor,String texto)throws IllegalArgumentException{
		if(id<=0) throw new IllegalArgumentException("El id no puede ser negativo");
		this.id=id;
		this.autor=autor;
		this.texto=texto;
	}
	
	/**
	 * Este metodo es el que crea la estructura de salida por consola. Haciendo que solo tenga que sustituirse los valores y ya.
	 */
	
	@Override
	public String toString(){
		String cad="";
		cad+="\nENTRADA DE"+separador+autor;
		cad+="\n "+texto;
		return cad;
	}
	
	/**
	 * Devuelve el id de la entrada.
	 * @return id
	 */ 
	
	
	public int getId(){
		return this.id;
	}
	
	/**
	 * Devuelve el texto de la entrada.
	 * @return texto
	 */
	
	
	public String getTexto(){
		return this.texto;
	}
	
	/**
	 * Devuelve el autor de la entrada en mayusculas.
	 * @return autor
	 */
	
	public String getAutor(){
		return this.autor.toUpperCase();
	}
	
	/**
	 * Devuelve el autor de la entrada.
	 * @deprecated
	 * @see getAutor
	 * @return autor
	 */
	
	public String devuelveAutor(){
		return this.autor;
	}
	
	/**
	 * clase main, puede no tener argumentos.
	 * @param args <i> clase main. </i>
	 */
	
	public static void main(String[] args) {
        
			/**
             * Modificado el id de "-3" a "1" para que no de error y arroje la excepcion "IllegalArgumentException" y as� pueda ejecutarse el programa. Adem�s no tiene mucho sentido que una id sea 0 o inferior.
             */
		
		EntradaBlog_INICIALES e1 =new EntradaBlog_INICIALES (1,"ana","�ltimas noticias, est� disponible BixBy 2.0");
		System.out.println(e1);
	}	
}